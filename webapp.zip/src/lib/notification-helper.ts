import { NotificationService } from './database';
import { settingsQueries, SystemSettings } from './database-queries';
import { SCHOOL_ID } from './constants';
import { Timestamp } from 'firebase/firestore';

export type NotificationType = 
  | 'student_registration'
  | 'payment_reminder'
  | 'attendance_report'
  | 'system_alert'
  | 'exam_schedule'
  | 'exam_results'
  | 'homework_assignment'
  | 'homework_reminder'
  | 'class_announcement'
  | 'notice_notification'
  | 'event_reminder'
  | 'message_notification'
  | 'complaint_response'
  | 'fee_payment_confirmation'
  | 'admission_confirmation'
  | 'teacher_assignment'
  | 'class_schedule';

interface SendNotificationOptions {
  userId: string;
  schoolId: string;
  title: string;
  message: string;
  type: NotificationType;
  notificationType?: 'attendance' | 'announcement' | 'alert';
}

/**
 * Check if a notification type is enabled in settings
 */
async function isNotificationEnabled(
  type: NotificationType,
  channel: 'email' | 'push'
): Promise<boolean> {
  try {
    const settings = await settingsQueries.getSettings();
    if (!settings) return true; // Default to enabled if settings not found

    const key = `${type}${channel === 'email' ? 'Email' : 'Push'}`;
    
    // Map notification types to settings keys
    const settingsMap: Record<NotificationType, { email: string; push: string }> = {
      student_registration: { email: 'studentRegistrationEmail', push: 'studentRegistrationPush' },
      payment_reminder: { email: 'paymentReminderEmail', push: 'paymentReminderPush' },
      attendance_report: { email: 'attendanceReportEmail', push: 'attendanceReportPush' },
      system_alert: { email: 'systemAlertEmail', push: 'systemAlertPush' },
      exam_schedule: { email: 'examScheduleEmail', push: 'examSchedulePush' },
      exam_results: { email: 'examResultsEmail', push: 'examResultsPush' },
      homework_assignment: { email: 'homeworkAssignmentEmail', push: 'homeworkAssignmentPush' },
      homework_reminder: { email: 'homeworkReminderEmail', push: 'homeworkReminderPush' },
      class_announcement: { email: 'classAnnouncementEmail', push: 'classAnnouncementPush' },
      notice_notification: { email: 'noticeNotificationEmail', push: 'noticeNotificationPush' },
      event_reminder: { email: 'eventReminderEmail', push: 'eventReminderPush' },
      message_notification: { email: 'messageNotificationEmail', push: 'messageNotificationPush' },
      complaint_response: { email: 'complaintResponseEmail', push: 'complaintResponsePush' },
      fee_payment_confirmation: { email: 'feePaymentConfirmationEmail', push: 'feePaymentConfirmationPush' },
      admission_confirmation: { email: 'admissionConfirmationEmail', push: 'admissionConfirmationPush' },
      teacher_assignment: { email: 'teacherAssignmentEmail', push: 'teacherAssignmentPush' },
      class_schedule: { email: 'classScheduleEmail', push: 'classSchedulePush' },
    };

    const settingKey = settingsMap[type]?.[channel];
    if (!settingKey) return true; // Default to enabled if type not found

    return (settings as any)[settingKey] !== false; // Default to true if undefined
  } catch (error) {
    console.error('Error checking notification settings:', error);
    return true; // Default to enabled on error
  }
}

/**
 * Send notification to a user
 * Checks settings before sending
 */
export async function sendNotification(options: SendNotificationOptions): Promise<boolean> {
  try {
    const { userId, schoolId, title, message, type, notificationType = 'announcement' } = options;

    // Check if push notification is enabled (we'll send in-app notification regardless)
    // Email notifications would be handled separately
    const pushEnabled = await isNotificationEnabled(type, 'push');
    
    // Create in-app notification (always send if push enabled, or if settings allow)
    if (pushEnabled) {
      const notificationData = {
        userId,
        schoolId: schoolId || SCHOOL_ID,
        title,
        message,
        type: notificationType,
        isRead: false,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      };

      const result = await NotificationService.createNotification(notificationData);
      
      if (!result.success) {
        console.error('Failed to create notification:', result.error);
        return false;
      }

      return true;
    }

    return false;
  } catch (error) {
    console.error('Error sending notification:', error);
    return false;
  }
}

/**
 * Send notifications to multiple users
 */
export async function sendBulkNotifications(
  userIds: string[],
  options: Omit<SendNotificationOptions, 'userId'>
): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;

  for (const userId of userIds) {
    const result = await sendNotification({ ...options, userId });
    if (result) {
      success++;
    } else {
      failed++;
    }
  }

  return { success, failed };
}

/**
 * Send notification to users by role
 */
export async function sendNotificationToRole(
  role: 'student' | 'teacher' | 'parent' | 'admin',
  options: Omit<SendNotificationOptions, 'userId' | 'schoolId'>
): Promise<{ success: number; failed: number }> {
  try {
    // This would need to fetch users by role from database
    // For now, return placeholder
    console.warn('sendNotificationToRole: Not implemented yet. Need to fetch users by role.');
    return { success: 0, failed: 0 };
  } catch (error) {
    console.error('Error sending notification to role:', error);
    return { success: 0, failed: 0 };
  }
}

