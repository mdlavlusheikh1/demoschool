// School Configuration Constants
export const SCHOOL_ID = '102330';

// Other school-related constants can be added here
export const SCHOOL_NAME = 'ইকরা নূরানী একাডেমি';
export const SCHOOL_ADDRESS = 'Dhaka, Bangladesh';
