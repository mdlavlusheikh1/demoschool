'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import TeacherLayout from '@/components/TeacherLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import { useAuth } from '@/contexts/AuthContext';
import { attendanceQueries, studentQueries, classQueries, AttendanceRecord, Class } from '@/lib/database-queries';
import {
  Search, Plus, Calendar, CheckCircle, XCircle, Clock, Loader2, RefreshCw, Filter, UserCheck, X, BookOpen
} from 'lucide-react';
import { serverTimestamp } from 'firebase/firestore';
import { User as StudentUser } from '@/lib/database-queries';

function AttendancePage() {
  const { userData } = useAuth();
  const router = useRouter();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedClass, setSelectedClass] = useState('all');
  const [classes, setClasses] = useState<Class[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [students, setStudents] = useState<StudentUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  const [bulkAttendanceStatus, setBulkAttendanceStatus] = useState<'present' | 'absent' | 'late'>('present');
  const [bulkModalSelectedClass, setBulkModalSelectedClass] = useState<string>('all');
  const [bulkLoading, setBulkLoading] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    loadClasses();
  }, []);

  useEffect(() => {
    if (selectedDate && userData && students.length > 0) {
      loadAttendanceRecords();
    }
  }, [selectedDate, selectedClass, userData, students]);

  useEffect(() => {
    loadStudents();
  }, []);

  // Auto-close success modal after 3 seconds
  useEffect(() => {
    if (showSuccessModal) {
      const timer = setTimeout(() => {
        setShowSuccessModal(false);
        setSuccessMessage('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showSuccessModal]);

  const loadClasses = async () => {
    try {
      const classesData = await classQueries.getAllClasses();
      setClasses(classesData);
    } catch (error) {
      console.error('Error loading classes:', error);
    }
  };

  const loadStudents = async () => {
    try {
      const studentsData = await studentQueries.getAllStudents(false);
      setStudents(studentsData);
    } catch (error) {
      console.error('Error loading students:', error);
    }
  };

  const loadAttendanceRecords = async () => {
    setLoading(true);
    try {
      const schoolId = userData?.schoolId || '102330';
      console.log('🔍 Loading attendance for date:', selectedDate);
      const records = await attendanceQueries.getAttendanceByDateAndClass(selectedDate, selectedClass || 'all');
      console.log('📊 Total records from Firebase:', records.length);
      console.log('📋 Sample dates from records:', records.slice(0, 5).map(r => r.date));
      
      console.log('🏫 School IDs in records:', [...new Set(records.map(r => r.schoolId))]);
      console.log('🎯 Current user schoolId:', schoolId);
      
      // Show all records for now (remove strict school filter)
      const filteredRecords = records;
      console.log('✅ After school filter:', filteredRecords.length);
      
      // Enrich records with student data (roll number)
      const enrichedRecords = filteredRecords.map(record => {
        const student = students.find(s => s.uid === record.studentId);
        return {
          ...record,
          rollNumber: student?.rollNumber || student?.studentId || '-',
          studentName: record.studentName || student?.displayName || student?.name || 'Unknown'
        };
      });
      
      console.log('🎯 Final enriched records:', enrichedRecords.length);
      setAttendanceRecords(enrichedRecords);
    } catch (error: any) {
      console.error('Error loading attendance:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredRecords = selectedClass === 'all'
    ? attendanceRecords
    : attendanceRecords.filter(r => r.classId === selectedClass);

  // Get unique students (remove duplicates by studentId)
  const uniqueRecordsMap = new Map();
  filteredRecords.forEach(record => {
    if (!uniqueRecordsMap.has(record.studentId)) {
      uniqueRecordsMap.set(record.studentId, record);
    }
  });
  const uniqueRecords = Array.from(uniqueRecordsMap.values());

  const presentCount = uniqueRecords.filter(r => r.status === 'present').length;
  const absentCount = uniqueRecords.filter(r => r.status === 'absent').length;
  const lateCount = uniqueRecords.filter(r => r.status === 'late').length;

  // Filter students for bulk modal based on modal class selection
  const bulkModalFilteredStudents = students.filter(student => {
    if (bulkModalSelectedClass === 'all') {
      return true;
    }
    
    // Find the selected class object to get its className
    const selectedClassObj = classes.find(c => c.classId === bulkModalSelectedClass);
    if (selectedClassObj) {
      // Match by className (since student.class stores the class name like "নার্সারি")
      return student.class === selectedClassObj.className;
    }
    
    // Fallback: direct comparison (in case student.class stores classId)
    return student.class === bulkModalSelectedClass;
  });

  // Handle bulk attendance mark
  const handleBulkAttendanceMark = async () => {
    if (!userData || selectedStudents.length === 0) return;

    // Check for already marked students
    const alreadyMarkedStudents = selectedStudents.filter(studentId => {
      return attendanceRecords.some(record => 
        record.studentId === studentId && record.date === selectedDate
      );
    });

    if (alreadyMarkedStudents.length > 0) {
      const alreadyMarkedNames = alreadyMarkedStudents.map(studentId => {
        const student = students.find(s => s.uid === studentId);
        return student?.displayName || student?.name || 'Unknown';
      }).join(', ');
      
      alert(`নিম্নলিখিত শিক্ষার্থীদের উপস্থিতি ইতিমধ্যে মার্ক করা হয়েছে:\n\n${alreadyMarkedNames}\n\nঅনুগ্রহ করে শুধুমাত্র নতুন শিক্ষার্থী নির্বাচন করুন।`);
      return;
    }

    setBulkLoading(true);
    try {
      const schoolId = userData?.schoolId || '102330';
      
      const promises = selectedStudents.map(studentId => {
        const student = students.find(s => s.uid === studentId);
        // Find the class object to get both classId and className
        const studentClass = student?.class ? classes.find(c => c.className === student.class) : null;
        
        return attendanceQueries.recordAttendance({
          studentId,
          studentName: student?.displayName || student?.name || 'Unknown',
          classId: studentClass?.classId || student?.class || 'unknown',
          className: student?.class || studentClass?.className || 'Unknown',
          schoolId: schoolId,
          date: selectedDate,
          status: bulkAttendanceStatus,
          timestamp: serverTimestamp() as any,
          teacherId: userData.uid,
          method: 'manual',
          rollNumber: student?.rollNumber || student?.studentId || '-'
        } as any);
      });

      await Promise.all(promises);
      await loadAttendanceRecords();
      setShowBulkModal(false);
      setSelectedStudents([]);
      setBulkModalSelectedClass('all');
      setSuccessMessage(`${selectedStudents.length} জন শিক্ষার্থীর উপস্থিতি মার্ক করা হয়েছে`);
      setShowSuccessModal(true);
    } catch (error) {
      console.error('Error marking bulk attendance:', error);
      alert('বাল্ক উপস্থিতি মার্ক করতে সমস্যা হয়েছে');
    } finally {
      setBulkLoading(false);
    }
  };

  return (
    <TeacherLayout title="উপস্থিতি ব্যবস্থাপনা" subtitle="শিক্ষার্থীদের উপস্থিতি রেকর্ড দেখুন এবং পরিচালনা করুন">
      <div className="space-y-6">
        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-2" />
                তারিখ নির্বাচন করুন
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Filter className="w-4 h-4 inline mr-2" />
                ক্লাস নির্বাচন করুন
              </label>
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="all">সকল ক্লাস</option>
                {classes.map((cls) => (
                  <option key={cls.classId} value={cls.classId}>
                    {cls.className} - {cls.section}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-end">
              <button
                onClick={loadAttendanceRecords}
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                <span>রিফ্রেশ</span>
              </button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">মোট</p>
                <p className="text-2xl font-bold text-gray-900">{uniqueRecords.length}</p>
              </div>
              <div className="p-3 bg-gray-100 rounded-lg">
                <Calendar className="w-6 h-6 text-gray-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">উপস্থিত</p>
                <p className="text-2xl font-bold text-green-600">{presentCount}</p>
              </div>
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">অনুপস্থিত</p>
                <p className="text-2xl font-bold text-red-600">{absentCount}</p>
              </div>
              <div className="p-3 bg-red-100 rounded-lg">
                <XCircle className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">বিলম্বিত</p>
                <p className="text-2xl font-bold text-yellow-600">{lateCount}</p>
              </div>
              <div className="p-3 bg-yellow-100 rounded-lg">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Attendance Records */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 text-green-600 animate-spin" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">রোল</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">নাম</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ক্লাস</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">অবস্থা</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">সময়</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {uniqueRecords.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center">
                        <div className="flex flex-col items-center justify-center space-y-3">
                          <Calendar className="w-12 h-12 text-gray-300" />
                          <p className="text-gray-500 font-medium">কোন উপস্থিতি রেকর্ড পাওয়া যায়নি</p>
                          <p className="text-sm text-gray-400">এই তারিখ এবং ক্লাসের জন্য এখনও উপস্থিতি নেওয়া হয়নি</p>
                          <button
                            onClick={() => router.push('/teacher/attendance/take')}
                            className="mt-2 flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                          >
                            <Plus className="w-4 h-4" />
                            <span>এখন উপস্থিতি নিন</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    uniqueRecords.map((record, index) => (
                      <tr key={record.id || `${record.studentId}-${record.date}-${index}`} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {(record as any).rollNumber || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="font-medium text-gray-900">{record.studentName}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                          {(record as any).className || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-3 py-1 text-xs font-medium rounded-full inline-flex items-center gap-1 ${
                            record.status === 'present'
                              ? 'bg-green-100 text-green-800'
                              : record.status === 'absent'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {record.status === 'present' && <CheckCircle className="w-3 h-3" />}
                            {record.status === 'absent' && <XCircle className="w-3 h-3" />}
                            {record.status === 'late' && <Clock className="w-3 h-3" />}
                            {record.status === 'present' ? 'উপস্থিত' : record.status === 'absent' ? 'অনুপস্থিত' : 'বিলম্বিত'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                          {record.timestamp?.toDate?.().toLocaleTimeString('bn-BD') || '-'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3">
          <button
            onClick={() => {
              setBulkModalSelectedClass(selectedClass !== 'all' ? selectedClass : 'all');
              setShowBulkModal(true);
            }}
            className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            <UserCheck className="w-5 h-5" />
            <span>বাল্ক মার্ক</span>
          </button>
          <button
            onClick={() => router.push('/teacher/attendance/take')}
            className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span>উপস্থিতি নিন</span>
          </button>
        </div>
      </div>

      {/* Bulk Attendance Modal */}
      {showBulkModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-modal-enter">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                    <UserCheck className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">বাল্ক উপস্থিতি মার্ক করুন</h3>
                    <p className="text-sm text-gray-600">একসাথে একাধিক শিক্ষার্থীর উপস্থিতি মার্ক করুন</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setShowBulkModal(false);
                    setSelectedStudents([]);
                    setBulkModalSelectedClass('all');
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Class Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">ক্লাস নির্বাচন করুন</label>
                <select
                  value={bulkModalSelectedClass}
                  onChange={(e) => {
                    setBulkModalSelectedClass(e.target.value);
                    setSelectedStudents([]); // Clear selections when class changes
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="all">সকল ক্লাস</option>
                  {classes.map((classItem) => (
                    <option key={classItem.classId} value={classItem.classId}>
                      {classItem.className} {classItem.section ? `(${classItem.section})` : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Attendance Status Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">উপস্থিতির অবস্থা নির্বাচন করুন</label>
                <div className="flex space-x-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      value="present"
                      checked={bulkAttendanceStatus === 'present'}
                      onChange={(e) => setBulkAttendanceStatus(e.target.value as 'present')}
                      className="mr-2"
                    />
                    <span className="text-green-600 font-medium">✓ উপস্থিত</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      value="late"
                      checked={bulkAttendanceStatus === 'late'}
                      onChange={(e) => setBulkAttendanceStatus(e.target.value as 'late')}
                      className="mr-2"
                    />
                    <span className="text-yellow-600 font-medium">⟲ বিলম্বে</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      value="absent"
                      checked={bulkAttendanceStatus === 'absent'}
                      onChange={(e) => setBulkAttendanceStatus(e.target.value as 'absent')}
                      className="mr-2"
                    />
                    <span className="text-red-600 font-medium">✗ অনুপস্থিত</span>
                  </label>
                </div>
              </div>

              {/* Students Selection */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <label className="block text-sm font-medium text-gray-700">শিক্ষার্থী নির্বাচন করুন</label>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => {
                        const unmarkedStudents = bulkModalFilteredStudents.filter(s => 
                          !attendanceRecords.some(record => record.studentId === s.uid && record.date === selectedDate)
                        );
                        setSelectedStudents(unmarkedStudents.map(s => s.uid));
                      }}
                      className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded hover:bg-blue-100"
                    >
                      সব নির্বাচন করুন
                    </button>
                    <button
                      onClick={() => setSelectedStudents([])}
                      className="text-xs bg-gray-50 text-gray-600 px-2 py-1 rounded hover:bg-gray-100"
                    >
                      সব মুক্ত করুন
                    </button>
                  </div>
                </div>

                <div className="max-h-64 overflow-y-auto border border-gray-200 rounded-lg">
                  {bulkModalFilteredStudents.length === 0 ? (
                    <div className="p-4 text-center text-gray-500 text-sm">
                      কোন শিক্ষার্থী পাওয়া যায়নি
                    </div>
                  ) : (
                    bulkModalFilteredStudents.map((student) => {
                      const isAlreadyMarked = attendanceRecords.some(record => 
                        record.studentId === student.uid && record.date === selectedDate
                      );
                      
                      return (
                        <label 
                          key={student.uid} 
                          className={`flex items-center p-3 border-b border-gray-100 last:border-b-0 ${
                            isAlreadyMarked ? 'bg-gray-50 opacity-60 cursor-not-allowed' : 'hover:bg-gray-50 cursor-pointer'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={selectedStudents.includes(student.uid)}
                            disabled={isAlreadyMarked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedStudents([...selectedStudents, student.uid]);
                              } else {
                                setSelectedStudents(selectedStudents.filter(id => id !== student.uid));
                              }
                            }}
                            className="mr-3"
                          />
                          <div className="flex items-center flex-1">
                            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center overflow-hidden mr-3">
                              {student.profileImage ? (
                                <img
                                  src={student.profileImage}
                                  alt={student.displayName || 'Student'}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <span className="text-white font-medium text-xs">
                                  {student.displayName?.split(' ')[0].charAt(0) || student.email?.charAt(0).toUpperCase()}
                                </span>
                              )}
                            </div>
                            <div className="flex-1">
                              <div className="text-sm font-medium text-gray-900">{student.displayName || student.name || 'Unknown'}</div>
                              <div className="text-xs text-gray-500">{student.studentId} • {student.class}</div>
                            </div>
                            {isAlreadyMarked && (
                              <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                                ✓ মার্ক করা হয়েছে
                              </span>
                            )}
                          </div>
                        </label>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Summary */}
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">নির্বাচিত শিক্ষার্থী:</span>
                  <span className="text-lg font-bold text-gray-900">{selectedStudents.length} জন</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-sm text-gray-600">অবস্থা:</span>
                  <span className={`text-sm font-medium ${
                    bulkAttendanceStatus === 'present' ? 'text-green-600' :
                    bulkAttendanceStatus === 'late' ? 'text-yellow-600' : 'text-red-600'
                  }`}>
                    {bulkAttendanceStatus === 'present' ? 'উপস্থিত' :
                     bulkAttendanceStatus === 'late' ? 'বিলম্বে' : 'অনুপস্থিত'}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-3">
                <button
                  onClick={() => {
                    setShowBulkModal(false);
                    setSelectedStudents([]);
                    setBulkModalSelectedClass('all');
                  }}
                  disabled={bulkLoading}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  বাতিল করুন
                </button>
                <button
                  onClick={handleBulkAttendanceMark}
                  disabled={bulkLoading || selectedStudents.length === 0}
                  className="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  {bulkLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>মার্ক করছি...</span>
                    </>
                  ) : (
                    <>
                      <UserCheck className="w-4 h-4" />
                      <span>মার্ক করুন ({selectedStudents.length})</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccessModal && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn"
          onClick={() => {
            setShowSuccessModal(false);
            setSuccessMessage('');
          }}
        >
          <div 
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full relative animate-modal-enter"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-8 text-center">
              {/* Success Icon */}
              <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-green-100 mb-6">
                <CheckCircle className="h-12 w-12 text-green-600" strokeWidth={2.5} />
              </div>
              
              {/* Success Message */}
              <h3 className="text-2xl font-bold text-gray-900 mb-3">সফল!</h3>
              <p className="text-lg text-gray-700 mb-8 leading-relaxed">{successMessage}</p>
              
              {/* OK Button */}
              <button
                onClick={() => {
                  setShowSuccessModal(false);
                  setSuccessMessage('');
                }}
                className="w-full px-6 py-3 bg-green-600 text-white font-semibold text-lg rounded-lg hover:bg-green-700 active:bg-green-800 transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-green-300 shadow-lg hover:shadow-xl transform hover:scale-[1.02] active:scale-[0.98]"
              >
                ঠিক আছে
              </button>
            </div>
          </div>
        </div>
      )}
    </TeacherLayout>
  );
}

export default function Page() {
  return (
    <ProtectedRoute requireAuth={true}>
      <AttendancePage />
    </ProtectedRoute>
  );
}
