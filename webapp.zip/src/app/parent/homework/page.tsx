'use client';

import ParentLayout from '@/components/ParentLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import { BookOpen, Calendar, CheckCircle, Clock, AlertCircle } from 'lucide-react';

function HomeworkPage() {
  return (
    <ParentLayout title="হোমওয়ার্ক" subtitle="সন্তানদের বাড়ির কাজ পর্যবেক্ষণ করুন">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">মোট হোমওয়ার্ক</p>
              <p className="text-3xl font-bold text-gray-900">8</p>
            </div>
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-gray-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">সম্পন্ন</p>
              <p className="text-3xl font-bold text-green-600">6</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">অপেক্ষমান</p>
              <p className="text-3xl font-bold text-yellow-600">2</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">বিলম্বিত</p>
              <p className="text-3xl font-bold text-red-600">0</p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Homework List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">সাম্প্রতিক হোমওয়ার্ক</h2>
        </div>
        
        <div className="p-6">
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">গণিত - অধ্যায় ৫ এর অনুশীলনী</h3>
                  <p className="text-sm text-gray-600 mt-1">শিক্ষার্থী: রাহুল আহমেদ (ক্লাস নাইন)</p>
                  <p className="text-sm text-gray-600">বিষয়: গণিত | শিক্ষক: মোঃ রহিম উদ্দিন</p>
                  <div className="flex items-center mt-2">
                    <Calendar className="w-4 h-4 text-yellow-600 mr-1" />
                    <span className="text-sm text-yellow-600">জমা দিতে হবে: ১০ নভেম্বর ২০২৫</span>
                  </div>
                </div>
                <span className="px-3 py-1 bg-yellow-600 text-white text-xs font-medium rounded-full">অপেক্ষমান</span>
              </div>
            </div>

            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">বাংলা - রচনা লিখন</h3>
                  <p className="text-sm text-gray-600 mt-1">শিক্ষার্থী: রাহুল আহমেদ (ক্লাস নাইন)</p>
                  <p className="text-sm text-gray-600">বিষয়: বাংলা | শিক্ষক: মিসেস ফাতেমা</p>
                  <div className="flex items-center mt-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-1" />
                    <span className="text-sm text-green-600">জমা দেওয়া হয়েছে: ০৫ নভেম্বর ২০২৫</span>
                  </div>
                </div>
                <span className="px-3 py-1 bg-green-600 text-white text-xs font-medium rounded-full">সম্পন্ন</span>
              </div>
            </div>

            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">ইংরেজি - Reading Comprehension</h3>
                  <p className="text-sm text-gray-600 mt-1">শিক্ষার্থী: সারা আহমেদ (ক্লাস সেভেন)</p>
                  <p className="text-sm text-gray-600">বিষয়: ইংরেজি | শিক্ষক: মিস তাহমিনা</p>
                  <div className="flex items-center mt-2">
                    <Calendar className="w-4 h-4 text-yellow-600 mr-1" />
                    <span className="text-sm text-yellow-600">জমা দিতে হবে: ১২ নভেম্বর ২০২৫</span>
                  </div>
                </div>
                <span className="px-3 py-1 bg-yellow-600 text-white text-xs font-medium rounded-full">অপেক্ষমান</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ParentLayout>
  );
}

export default function Page() {
  return (
    <ProtectedRoute>
      <HomeworkPage />
    </ProtectedRoute>
  );
}
