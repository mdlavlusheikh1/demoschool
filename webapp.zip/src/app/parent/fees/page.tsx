'use client';

import ParentLayout from '@/components/ParentLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import { DollarSign, CreditCard, Clock, CheckCircle, AlertCircle } from 'lucide-react';

function FeesPage() {
  return (
    <ParentLayout title="ফিস ও পেমেন্ট" subtitle="সন্তানদের ফি এবং পেমেন্ট ইতিহাস">
      {/* Payment Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">মোট বকেয়া</p>
              <p className="text-3xl font-bold text-red-600">৳ 2,500</p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">পরিশোধিত</p>
              <p className="text-3xl font-bold text-green-600">৳ 12,000</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">মোট ফি</p>
              <p className="text-3xl font-bold text-blue-600">৳ 14,500</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Fee Details */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-6">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">ফি বিবরণ</h2>
        </div>
        
        <div className="p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-lg">
              <div>
                <h3 className="font-semibold text-gray-900">নভেম্বর ২০২৫ - টিউশন ফি</h3>
                <p className="text-sm text-gray-600">শিক্ষার্থী: রাহুল আহমেদ (ক্লাস নাইন)</p>
                <p className="text-xs text-red-600 mt-1">পরিশোধের তারিখ: ০৫ নভেম্বর ২০২৫</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-red-600">৳ 1,500</p>
                <span className="inline-block mt-2 px-3 py-1 bg-red-600 text-white text-xs font-medium rounded-full">বকেয়া</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div>
                <h3 className="font-semibold text-gray-900">নভেম্বর ২০২৫ - টিউশন ফি</h3>
                <p className="text-sm text-gray-600">শিক্ষার্থী: সারা আহমেদ (ক্লাস সেভেন)</p>
                <p className="text-xs text-yellow-600 mt-1">পরিশোধের তারিখ: ০৫ নভেম্বর ২০২৫</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-yellow-600">৳ 1,000</p>
                <span className="inline-block mt-2 px-3 py-1 bg-yellow-600 text-white text-xs font-medium rounded-full">বকেয়া</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
              <div>
                <h3 className="font-semibold text-gray-900">অক্টোবর ২০২৫ - টিউশন ফি</h3>
                <p className="text-sm text-gray-600">শিক্ষার্থী: রাহুল আহমেদ</p>
                <p className="text-xs text-green-600 mt-1">পরিশোধিত: ০১ অক্টোবর ২০২৫</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-green-600">৳ 1,500</p>
                <span className="inline-block mt-2 px-3 py-1 bg-green-600 text-white text-xs font-medium rounded-full">পরিশোধিত</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Methods */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">পেমেন্ট মেথড</h2>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="p-4 border-2 border-blue-600 rounded-lg hover:bg-blue-50 transition-colors">
              <CreditCard className="w-8 h-8 mx-auto text-blue-600 mb-2" />
              <p className="text-sm font-semibold text-gray-900">অনলাইন পেমেন্ট</p>
            </button>
            
            <button className="p-4 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <DollarSign className="w-8 h-8 mx-auto text-gray-600 mb-2" />
              <p className="text-sm font-semibold text-gray-900">ব্যাংক ট্রান্সফার</p>
            </button>
            
            <button className="p-4 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Clock className="w-8 h-8 mx-auto text-gray-600 mb-2" />
              <p className="text-sm font-semibold text-gray-900">নগদ পেমেন্ট</p>
            </button>
          </div>
        </div>
      </div>
    </ParentLayout>
  );
}

export default function Page() {
  return (
    <ProtectedRoute>
      <FeesPage />
    </ProtectedRoute>
  );
}
