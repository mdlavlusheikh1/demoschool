'use client';

import ParentLayout from '@/components/ParentLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import { MessageSquare, Send, User, Clock } from 'lucide-react';

function MessagesPage() {
  return (
    <ParentLayout title="বার্তা" subtitle="শিক্ষকদের সাথে যোগাযোগ করুন">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Conversation List */}
        <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-bold text-gray-900">কথোপকথন</h2>
          </div>
          
          <div className="divide-y divide-gray-100">
            <div className="p-4 hover:bg-gray-50 cursor-pointer bg-blue-50">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-900">মোঃ রহিম উদ্দিন</p>
                  <p className="text-xs text-gray-600 truncate">গণিত শিক্ষক - ক্লাস নাইন</p>
                  <p className="text-xs text-gray-500 mt-1 truncate">হ্যালো, আপনার সন্তানের অগ্রগতি...</p>
                </div>
                <span className="text-xs text-gray-400">২ ঘন্টা</span>
              </div>
            </div>

            <div className="p-4 hover:bg-gray-50 cursor-pointer">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-900">মিসেস ফাতেমা</p>
                  <p className="text-xs text-gray-600 truncate">বাংলা শিক্ষক - ক্লাস নাইন</p>
                  <p className="text-xs text-gray-500 mt-1 truncate">ধন্যবাদ আপনার মেসেজের জন্য</p>
                </div>
                <span className="text-xs text-gray-400">১ দিন</span>
              </div>
            </div>

            <div className="p-4 hover:bg-gray-50 cursor-pointer">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-900">মিস তাহমিনা</p>
                  <p className="text-xs text-gray-600 truncate">ইংরেজি শিক্ষক - ক্লাস সেভেন</p>
                  <p className="text-xs text-gray-500 mt-1 truncate">আপনার মেয়ে খুব ভালো করছে</p>
                </div>
                <span className="text-xs text-gray-400">২ দিন</span>
              </div>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col h-[600px]">
          {/* Chat Header */}
          <div className="p-4 border-b border-gray-200 flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-900">মোঃ রহিম উদ্দিন</p>
              <p className="text-xs text-gray-600">গণিত শিক্ষক - ক্লাস নাইন</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div className="flex justify-start">
              <div className="bg-gray-100 rounded-lg p-3 max-w-sm">
                <p className="text-sm text-gray-900">হ্যালো, আপনার সন্তান রাহুল আহমেদ এর অগ্রগতি নিয়ে আলোচনা করতে চাই।</p>
                <p className="text-xs text-gray-500 mt-1">১০:৩০ AM</p>
              </div>
            </div>

            <div className="flex justify-end">
              <div className="bg-blue-600 rounded-lg p-3 max-w-sm">
                <p className="text-sm text-white">অবশ্যই। আমি শুনতে আগ্রহী।</p>
                <p className="text-xs text-blue-200 mt-1">১০:৩২ AM</p>
              </div>
            </div>

            <div className="flex justify-start">
              <div className="bg-gray-100 rounded-lg p-3 max-w-sm">
                <p className="text-sm text-gray-900">রাহুল গণিতে খুবই ভালো করছে। গত পরীক্ষায় সে ৯৮ পেয়েছে।</p>
                <p className="text-xs text-gray-500 mt-1">১০:৩৫ AM</p>
              </div>
            </div>

            <div className="flex justify-end">
              <div className="bg-blue-600 rounded-lg p-3 max-w-sm">
                <p className="text-sm text-white">এটা শুনে খুবই ভালো লাগলো! আপনার সহযোগিতার জন্য ধন্যবাদ।</p>
                <p className="text-xs text-blue-200 mt-1">১০:৩৭ AM</p>
              </div>
            </div>
          </div>

          {/* Message Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                placeholder="মেসেজ লিখুন..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </ParentLayout>
  );
}

export default function Page() {
  return (
    <ProtectedRoute>
      <MessagesPage />
    </ProtectedRoute>
  );
}
