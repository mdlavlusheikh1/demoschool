'use client';

import ParentLayout from '@/components/ParentLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import { Award, TrendingUp, TrendingDown, FileText, Calendar } from 'lucide-react';

function ResultsPage() {
  return (
    <ParentLayout title="পরীক্ষার ফলাফল" subtitle="সন্তানদের পরীক্ষার ফলাফল দেখুন">
      {/* Results Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">সর্বশেষ পরীক্ষা</p>
              <p className="text-2xl font-bold text-gray-900">মাসিক পরীক্ষা</p>
              <p className="text-sm text-gray-500 mt-1">নভেম্বর ২০২৫</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">গড় গ্রেড</p>
              <p className="text-3xl font-bold text-green-600">A+</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Award className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">পরবর্তী পরীক্ষা</p>
              <p className="text-2xl font-bold text-gray-900">সাময়িক</p>
              <p className="text-sm text-gray-500 mt-1">১৫ ডিসেম্বর ২০২৫</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Student Results */}
      <div className="space-y-6">
        {/* Student 1 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-blue-100">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-900">রাহুল আহমেদ</h2>
                <p className="text-sm text-gray-600">ক্লাস নাইন - বিভাগ এ</p>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold text-green-600">A+</p>
                <p className="text-sm text-gray-600">GPA: 5.00</p>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 text-sm font-semibold text-gray-700">বিষয়</th>
                  <th className="text-center py-3 text-sm font-semibold text-gray-700">নম্বর</th>
                  <th className="text-center py-3 text-sm font-semibold text-gray-700">গ্রেড</th>
                  <th className="text-center py-3 text-sm font-semibold text-gray-700">অবস্থান</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-100">
                  <td className="py-3 text-sm text-gray-900">বাংলা</td>
                  <td className="py-3 text-sm text-center text-gray-900">৯৫/১০০</td>
                  <td className="py-3 text-sm text-center">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full font-semibold">A+</span>
                  </td>
                  <td className="py-3 text-sm text-center flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                    <span className="text-green-600 font-semibold">১ম</span>
                  </td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 text-sm text-gray-900">ইংরেজি</td>
                  <td className="py-3 text-sm text-center text-gray-900">৯২/১০০</td>
                  <td className="py-3 text-sm text-center">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full font-semibold">A+</span>
                  </td>
                  <td className="py-3 text-sm text-center flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                    <span className="text-green-600 font-semibold">২য়</span>
                  </td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 text-sm text-gray-900">গণিত</td>
                  <td className="py-3 text-sm text-center text-gray-900">৯৮/১০০</td>
                  <td className="py-3 text-sm text-center">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full font-semibold">A+</span>
                  </td>
                  <td className="py-3 text-sm text-center flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                    <span className="text-green-600 font-semibold">১ম</span>
                  </td>
                </tr>
                <tr>
                  <td className="py-3 text-sm text-gray-900">বিজ্ঞান</td>
                  <td className="py-3 text-sm text-center text-gray-900">৯৪/১০০</td>
                  <td className="py-3 text-sm text-center">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full font-semibold">A+</span>
                  </td>
                  <td className="py-3 text-sm text-center flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                    <span className="text-green-600 font-semibold">১ম</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Student 2 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-pink-50 to-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-900">সারা আহমেদ</h2>
                <p className="text-sm text-gray-600">ক্লাস সেভেন - বিভাগ বি</p>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold text-green-600">A</p>
                <p className="text-sm text-gray-600">GPA: 4.75</p>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 text-sm font-semibold text-gray-700">বিষয়</th>
                  <th className="text-center py-3 text-sm font-semibold text-gray-700">নম্বর</th>
                  <th className="text-center py-3 text-sm font-semibold text-gray-700">গ্রেড</th>
                  <th className="text-center py-3 text-sm font-semibold text-gray-700">অবস্থান</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-100">
                  <td className="py-3 text-sm text-gray-900">বাংলা</td>
                  <td className="py-3 text-sm text-center text-gray-900">৯০/১০০</td>
                  <td className="py-3 text-sm text-center">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full font-semibold">A+</span>
                  </td>
                  <td className="py-3 text-sm text-center flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                    <span className="text-green-600 font-semibold">৩য়</span>
                  </td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 text-sm text-gray-900">ইংরেজি</td>
                  <td className="py-3 text-sm text-center text-gray-900">৮৮/১০০</td>
                  <td className="py-3 text-sm text-center">
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full font-semibold">A</span>
                  </td>
                  <td className="py-3 text-sm text-center flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-blue-600 mr-1" />
                    <span className="text-blue-600 font-semibold">৫ম</span>
                  </td>
                </tr>
                <tr>
                  <td className="py-3 text-sm text-gray-900">গণিত</td>
                  <td className="py-3 text-sm text-center text-gray-900">৯২/১০০</td>
                  <td className="py-3 text-sm text-center">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full font-semibold">A+</span>
                  </td>
                  <td className="py-3 text-sm text-center flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                    <span className="text-green-600 font-semibold">২য়</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </ParentLayout>
  );
}

export default function Page() {
  return (
    <ProtectedRoute>
      <ResultsPage />
    </ProtectedRoute>
  );
}
