'use client';

import ParentLayout from '@/components/ParentLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import { Calendar, MapPin, Clock, Users, Bell } from 'lucide-react';

function EventsPage() {
  return (
    <ParentLayout title="ইভেন্ট ও সময়সূচী" subtitle="আসন্ন ইভেন্ট এবং গুরুত্বপূর্ণ তারিখ">
      {/* Upcoming Events */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-6">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">আসন্ন ইভেন্ট</h2>
        </div>
        
        <div className="p-6">
          <div className="space-y-4">
            <div className="p-4 bg-gradient-to-r from-blue-50 to-blue-100 border border-blue-200 rounded-lg">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 text-lg">সাময়িক পরীক্ষা</h3>
                  <div className="flex items-center text-sm text-gray-600 mt-2">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>১৫ ডিসেম্বর ২০২৫ - ২০ ডিসেম্বর ২০২৫</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600 mt-1">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>পরীক্ষা হল</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">সকল শিক্ষার্থীদের জন্য সাময়িক পরীক্ষা অনুষ্ঠিত হবে।</p>
                </div>
                <span className="px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded-full">১০ দিন বাকি</span>
              </div>
            </div>

            <div className="p-4 bg-gradient-to-r from-green-50 to-green-100 border border-green-200 rounded-lg">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 text-lg">অভিভাবক-শিক্ষক সভা</h3>
                  <div className="flex items-center text-sm text-gray-600 mt-2">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>১০ নভেম্বর ২০২৫, সকাল ১০:০০ টা</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600 mt-1">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>স্কুল সভাকক্ষ</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">শিক্ষার্থীদের অগ্রগতি নিয়ে আলোচনা করা হবে।</p>
                </div>
                <span className="px-3 py-1 bg-green-600 text-white text-xs font-medium rounded-full">৩ দিন বাকি</span>
              </div>
            </div>

            <div className="p-4 bg-gradient-to-r from-purple-50 to-purple-100 border border-purple-200 rounded-lg">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                  <Bell className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 text-lg">বার্ষিক ক্রীড়া প্রতিযোগিতা</h3>
                  <div className="flex items-center text-sm text-gray-600 mt-2">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>২৫ ডিসেম্বর ২০২৫</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600 mt-1">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>স্কুল খেলার মাঠ</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">সকল শিক্ষার্থীদের জন্য বার্ষিক ক্রীড়া প্রতিযোগিতা।</p>
                </div>
                <span className="px-3 py-1 bg-purple-600 text-white text-xs font-medium rounded-full">২০ দিন বাকি</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* School Calendar */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">স্কুল ক্যালেন্ডার</h2>
        </div>
        
        <div className="p-6">
          <div className="text-center py-12 text-gray-500">
            <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-lg font-medium">পূর্ণ ক্যালেন্ডার শীঘ্রই আসছে</p>
            <p className="text-sm mt-1">সকল ইভেন্ট এবং ছুটির দিন এখানে দেখানো হবে</p>
          </div>
        </div>
      </div>
    </ParentLayout>
  );
}

export default function Page() {
  return (
    <ProtectedRoute>
      <EventsPage />
    </ProtectedRoute>
  );
}
