'use client';

import ParentLayout from '@/components/ParentLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import { Bell, Calendar, AlertCircle, Info } from 'lucide-react';

function NoticePage() {
  return (
    <ParentLayout title="নোটিশ" subtitle="গুরুত্বপূর্ণ বিজ্ঞপ্তি এবং ঘোষণা">
      {/* Important Notices */}
      <div className="space-y-4 mb-6">
        <div className="bg-red-50 border border-red-200 rounded-xl p-6">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900">জরুরি: পরীক্ষার সময়সূচী পরিবর্তন</h3>
                <span className="text-xs text-gray-500">২ ঘন্টা আগে</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                সাময়িক পরীক্ষার সময়সূচীতে কিছু পরিবর্তন করা হয়েছে। নতুন সময়সূচী স্কুল নোটিশ বোর্ডে দেওয়া হয়েছে।
              </p>
              <div className="flex items-center text-xs text-gray-500 mt-3">
                <Calendar className="w-3 h-3 mr-1" />
                <span>প্রকাশিত: ০৭ নভেম্বর ২০২৫</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
              <Info className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900">অভিভাবক-শিক্ষক সভা আগামীকাল</h3>
                <span className="text-xs text-gray-500">১ দিন আগে</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                আগামীকাল সকাল ১০:০০ টায় অভিভাবক-শিক্ষক সভা অনুষ্ঠিত হবে। সকল অভিভাবকদের উপস্থিত থাকার জন্য অনুরোধ করা হচ্ছে।
              </p>
              <div className="flex items-center text-xs text-gray-500 mt-3">
                <Calendar className="w-3 h-3 mr-1" />
                <span>প্রকাশিত: ০৬ নভেম্বর ২০২৫</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
              <Bell className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900">শীতকালীন ছুটির তালিকা</h3>
                <span className="text-xs text-gray-500">৩ দিন আগে</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                শীতকালীন ছুটি ১৫ জানুয়ারি থেকে ৩১ জানুয়ারি ২০২৬ পর্যন্ত থাকবে। স্কুল ১ ফেব্রুয়ারি পুনরায় খুলবে।
              </p>
              <div className="flex items-center text-xs text-gray-500 mt-3">
                <Calendar className="w-3 h-3 mr-1" />
                <span>প্রকাশিত: ০৪ নভেম্বর ২০২৫</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
              <Bell className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900">বার্ষিক ক্রীড়া প্রতিযোগিতা</h3>
                <span className="text-xs text-gray-500">১ সপ্তাহ আগে</span>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                বার্ষিক ক্রীড়া প্রতিযোগিতা ২৫ ডিসেম্বর ২০২৫ তারিখে অনুষ্ঠিত হবে। সকল শিক্ষার্থীদের অংশগ্রহণ করার জন্য উৎসাহিত করা হচ্ছে।
              </p>
              <div className="flex items-center text-xs text-gray-500 mt-3">
                <Calendar className="w-3 h-3 mr-1" />
                <span>প্রকাশিত: ৩১ অক্টোবর ২০২৫</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ParentLayout>
  );
}

export default function Page() {
  return (
    <ProtectedRoute>
      <NoticePage />
    </ProtectedRoute>
  );
}
